/*
 * stm32f407xx_gpio_driver.h
 *
 *  Created on: 17-Sep-2021
 *      Author: rahul
 */

#ifndef INC_STM32F407XX_GPIO_DRIVER_H_
#define INC_STM32F407XX_GPIO_DRIVER_H_


#include "stm32f4xx.h"

typedef struct
{
	uint32_t GPIO_PinNumber;
	uint32_t GPIO_PinMode;
	uint32_t GPIO_PinSpeed;
	uint32_t GPIO_PinPinPupControl;
	uint32_t GPIO_PinOPType;
	uint32_t GPIO_PinAltFunMode;

}GPIO_PinConfig_t;


typedef struct
{
	GPIO_RegDef_t *pGPIOx;    //BASE ADSRESS
	GPIO_PinConfig_t GPIO_Config;  // PIN CONFIGURATION
}GPIO_Handle_t;


/*
 * GPIO PIN Number
 */
#define GPIO_PIN_NO_0   0
#define GPIO_PIN_NO_1   1
#define GPIO_PIN_NO_2   2
#define GPIO_PIN_NO_3   3
#define GPIO_PIN_NO_4   4
#define GPIO_PIN_NO_5   5
#define GPIO_PIN_NO_6   6
#define GPIO_PIN_NO_7   7
#define GPIO_PIN_NO_8   8
#define GPIO_PIN_NO_9   9
#define GPIO_PIN_NO_10  10
#define GPIO_PIN_NO_11  11
#define GPIO_PIN_NO_12  12
#define GPIO_PIN_NO_13  13
#define GPIO_PIN_NO_14  14
#define GPIO_PIN_NO_15  15


/*
 * GPIO PIN Mode
 */

#define GPIO_MODE_IN        0
#define GPIO_MODE_OUT       1
#define GPIO_MODE_ALTFN     2
#define GPIO_MODE_ANALA     3


/*
 * GPIO Speed
 */
#define SPEED_LOW     0
#define SPEED_MED     1
#define SPEED_HIGH    2
#define SPEED_VHIGH    3

/*
 * PUSH PULL CONTROL
 */

#define GPIO_NO_PUPD    0
#define GPIO_PUP        1
#define GPIO_PD         2

/*
 * PIN OP TYPE
 */

#define GPIO_OP_TYPE_PP    0
#define GPIO_OP_TYPE_OD    1




/*
 *
 *
 * USER Defined API's
 *
 *
 *
 */

      /*
      * API Init and DeInit
      */
       void GPIO_Init(GPIO_Handle_t *pGPIOHandle);
       void GPIO_DeInit(GPIO_RegDef_t *pGPIOx);
       /*
        * Peripheral Clock
        */

       void GPIO_PeriClockControl(GPIO_RegDef_t *pGPIOx, uint8_t EnorDi);

       /*
        * Data read and Write
        */
       uint8_t GPIO_ReadFromInputPin(GPIO_RegDef_t *pGPIOx, uint8_t PinNumber);
       uint16_t GPIO_ReadFromOutputPort(GPIO_RegDef_t *pGPIOx);
       void GPIO_WriteToOutputPin(GPIO_RegDef_t *pGPIOx, uint8_t PinNumber, uint8_t Value);
       void GPIO_WriteToOutputPort(GPIO_RegDef_t *pGPIOx, uint8_t Value);
       void GPIO_ToggleOutputPin(GPIO_RegDef_t *pGPIOx, uint8_t PinNumber);



#endif /* INC_STM32F407XX_GPIO_DRIVER_H_ */
