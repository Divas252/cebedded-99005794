#include "stm32f407xx_gpio_driver.h"

void init_Pushbutton(void);
void init_led(void);




int main (void)
{
	init_Pushbutton();
      init_led();
	  while(1)
	  {
		 if (GPIO_ReadFromInputPin(GPIOA,  GPIO_PIN_NO_0 ))
		 {
			void  GPIO_WriteToOutputPort( GPIOA , GPIO_PIN_NO_12|GPIO_PIN_NO_13|GPIO_PIN_NO_14|GPIO_PIN_NO_15)
			{
				GPIOA ->ODR = SET;
			}
			}


		 }
		  
		  
	  }
	void init_Pushbutton(void){
		
	GPIO_PeriClockControl(GPIOA, ENABLE);
    GPIO_Handle_t PUSHBUTTON;
	PUSHBUTTON.pGPIOx=GPIOA;
	PUSHBUTTON.GPIO_Config.GPIO_PinNumber = GPIO_PIN_NO_0;
	PUSHBUTTON.GPIO_Config.GPIO_PinMode = GPIO_MODE_IN;
	
	
	PUSHBUTTON.GPIO_Config.GPIO_PinPinPupControl = GPIO_NO_PUP;
      GPIO_Init(GPIO, &PUSHBUTTON);

		
	}
	  
	  
	  
	  
	  
	  
	  


int init_led(void)
{
	GPIO_Handle_t GpioLed;
	GpioLed.pGPIOx=GPIOD;
	GpioLed.GPIO_Config.GPIO_PinNumber = GPIO_PIN_NO_12|GPIO_PIN_NO_13|GPIO_PIN_NO_14|GPIO_PIN_NO_15;
	GpioLed.GPIO_Config.GPIO_PinMode = GPIO_MODE_OUT;
	GpioLed.GPIO_Config.GPIO_PinSpeed = SPEED_MED;
	GpioLed.GPIO_Config.GPIO_PinOPType = GPIO_OP_TYPE_PP;
	GpioLed.GPIO_Config.GPIO_PinPinPupControl = GPIO_NO_PUPD

	GPIO_PeriClockControl(GPIOD, ENABLE);
	GPIO_Init(&GpioLed);

}