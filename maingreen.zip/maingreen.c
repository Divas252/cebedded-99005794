#include "stm32f407xx_gpio_driver.h"


void delay(void)
{
	for(uint32_t i=0;i<500;i++);
}

int main(void)
{
	GPIO_Handle_t GpioLed;
	GpioLed.pGPIOx=GPIOD;
	GpioLed.GPIO_Config.GPIO_PinNumber = GPIO_PIN_NO_12;
	GpioLed.GPIO_Config.GPIO_PinMode = GPIO_MODE_OUT;
	GpioLed.GPIO_Config.GPIO_PinSpeed = SPEED_MED;
	GpioLed.GPIO_Config.GPIO_PinOPType = GPIO_OP_TYPE_PP;
	GpioLed.GPIO_Config.GPIO_PinPinPupControl = GPIO_NO_PUPD;

	GPIO_PeriClockControl(GPIOD, ENABLE);
	GPIO_Init(&GpioLed);

	for(uint32_t i=0;i<5000;i++);
	{
		GPIO_ToggleOutputPin(GPIOD, GPIO_PIN_NO_12);
		delay();

	}
	
}
